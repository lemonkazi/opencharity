jQuery(document).ready(function ($) {

// var container = $("#carousel_wrapper");
    
//     var runner = container.find('ul');
//     var liWidth = runner.find('li:first').outerWidth();
//     var itemsPerPage = 4;
//     var noofitems = runner.find('li').length;
    
//     runner.width(noofitems * liWidth);
//     container.width(itemsPerPage*liWidth);

//     setInterval(function () {
//         moveRightcarousel();
//     }, 3000);


//     $('#right').click(function() {


//      //var width = $().outerWidth();
//      var width = '100px';
//      //var width = runner.find('.last-visible').outerWidth();
//        //  var width = $('4.last-visible').outerWidth(); // ~*~ is pseudo-code
//     var $runner = $(runner);
//     var left = $runner.prop('left') + width < $runner.width()
//                  ? "-=" + width + "px"
//                  : "0px";

//     $runner.animate({ "left": left }, "slow" );



//         //$( runner ).animate({ "left": "-=52px" }, "slow" );
//     });
//     function moveRightcarousel() {
//         $( runner ).animate({ "left": "-=52px" }, "slow" );


//     };
    
    
//     $('#left').click(function() {
//         $( runner ).animate({ "left": "+=51px" }, "slow" );
//     });

  // $('#checkbox').change(function(){
  //   setInterval(function () {
  //       moveRight();
  //   }, 3000);
  // });
   setInterval(function () {
        moveRight();
    }, 3000);
	var slideCount = $('#slider ul li').length;
	var slideWidth = $('#slider ul li').width();
	var slideHeight = $('#slider ul li').height();
	var sliderUlWidth = slideCount * slideWidth;
	
  $('#slider').css({ height: slideHeight });
  
  $('#slider ul').css({ width: sliderUlWidth, height: slideHeight });
  
  $('#slider ul li').css({ width: slideWidth });
  
    $('#slider ul li:last-child').prependTo('#slider ul');

    function moveLeft() {
        $('#slider ul').animate({
            left: + slideWidth
        }, 400, function () {
            $('#slider ul li:last-child').prependTo('#slider ul');
            $('#slider ul').css('left', '');
        });
    };

    function moveRight() {
        $('#slider ul').animate({
            left: - slideWidth
        }, 400, function () {
            $('#slider ul li:first-child').appendTo('#slider ul');
            $('#slider ul').css('left', '');
        });
    };

    $('a.control_prev').click(function () {
        moveLeft();
    });

    $('a.control_next').click(function () {
        moveRight();
    });

});  

$(document).ready(function() {

  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    autoplay:true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:true
        }
    }
});


// $("#owl-slider").owlCarousel({
//     items : 1,
//     autoPlay : true,
//     slideSpeed : 200,
//     stopOnHover : true,
//     navigation : false
// })

// $(document).ready(function() {
//     $("#owl-slider").owlCarousel();

// }); 



$(".slider").slick({
    autoplay: true,
    dots: true,
    arrows: true,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
     responsive: [
                            {
                              breakpoint: 1200,
                              settings: {
                                slidesToShow: 4,
                                slidesToScroll: 1
                              }
                            },
                            {
                              breakpoint: 1008,
                              settings: {
                                slidesToShow: 4,
                                slidesToScroll: 1
                              }
                            },
                            {
                              breakpoint: 800,
                              settings: {
                                slidesToShow: 2,
                                slidesToScroll: 1
                              }
                            },
                            {
                              breakpoint: 500,
                              settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                              }
                            }
                          ]

    // responsive: [{ 
    //     breakpoint: 500,
    //     settings: {
    //         dots: true,
    //         arrows: true,
    //         infinite: true,
    //         slidesToShow: 2,
    //         slidesToScroll: 2
    //     }
    //     }, 
    //     { 
    //     breakpoint: 1000,
    //     settings: {
    //         dots: true,
    //         arrows: true,
    //         infinite: true,
    //         slidesToShow: 4,
    //         slidesToScroll: 4
    //     } 
    // }]
});
});




