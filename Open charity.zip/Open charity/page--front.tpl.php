<?php
global $base_url;   // Will point to http://www.example.com
global $base_path;  // Will point to at least "/" or the subdirectory where the drupal in 
?>
<script type="text/javascript" src="https://rawgit.com/kenwheeler/slick/master/slick/slick.js"></script>

<script type="text/javascript">

 jQuery(function($) {

  });
</script>


  <div id="header">

    <!-- <a href="<?php print $front_page;?>" title="<?php print $site_name;?>">
      <img class="mk-desktop-logo dark-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-desktop-logo light-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-resposnive-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-sticky-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
    </a> -->

    <a href="<?php print $front_page;?>" title="<?php print $site_name;?>">
      <img src="<?php print $base_url; ?>/<?php print $directory;?>/images/logo.png" alt="<?php print $site_name;?>" height="47" width="217" />
    </a>

    <?php if ($main_menu): ?>
        <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'main-menu'))); ?>
    <?php endif; ?>

  </div>

  <div id="theme-page" class="master-holder  clearfix" itemscope="itemscope" itemtype="https://schema.org/Blog">
    <div class="master-holder-bg-holder">
    </div>
    <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">

      <div id="slider">
        <a href="#" class="control_next">></a>
        <a href="#" class="control_prev"><</a>
        <ul>
          <li>
            <div>
              <h1>Sharing Ideas For Charities</h1></br>
              <p>Many charities’ goals are similar, as is the functionality  we require, but little shared working takes place.</p></br>
              <p>By working together, driving shared areas of interest and influencing open source developments we can bring efficiencies, improve the digital experience for our users, and have great impact.
                Together we can make a bigger diference.</p>
            </div>
            <img src="<?php print $base_url; ?>/<?php print $directory;?>/images/1st_slider.png" />
          </li>
   

          <li style="background: #aaa;">
            <div>
              <h1>Sharing Ideas For Charities</h1></br>
              <p>Many charities’ goals are similar, as is the functionality  we require, but little shared working takes place.</p></br>
              <p>By working together, driving shared areas of interest and influencing open source developments we can bring efficiencies, improve the digital experience for our users, and have great impact.
                Together we can make a bigger diference.</p>
            </div>
            <img src="<?php print $base_url; ?>/<?php print $directory;?>/images/2nd_slider.png" />
          </li>
          <li>
            <div>
              <h1>Sharing Ideas For Charities</h1></br>
              <p>Many charities’ goals are similar, as is the functionality  we require, but little shared working takes place.</p></br>
              <p>By working together, driving shared areas of interest and influencing open source developments we can bring efficiencies, improve the digital experience for our users, and have great impact.
              Together we can make a bigger diference.</p>
            </div>
            <img src="<?php print $base_url; ?>/<?php print $directory;?>/images/3rd_slider.png" />
          </li>
        
        </ul>  
      </div>

     <!--  <div class="slider_option">
        <input type="checkbox" id="checkbox">
        <label for="checkbox">Autoplay Slider</label>
      </div>  -->

    </div>
  </div>
  <div class="vc_col-sm-12 slider-bottom red-background">
    <div class="vc_col-sm-12 slider-bottom-container">
    
      
        <div class="vc_column_container vc_col-sm-10">
          <div class="vc_column-inner">
            <div class="wpb_wrapper">
              <div class="mk-text-block">
                  <p style="text-align:left;" align="justify" class="bold-text">
                    <strong>Next Event:</strong>June 23rd 2016 18:30 - 21:00
                  </p>
                  <p style="text-align:left;" align="justify">
                    ancer Research UK, Angel Building, 407 St John Street, London EC1V 4AD 
                  </p>
                  <div class="clearboth">
                  </div>
              </div>
            </div>
          </div>
        </div>
        <div class="vc_column_container vc_col-sm-2">
          <div class="vc_column-inner">
            <div class="wpb_wrapper">
              <div id="mk-button-12" class="mk-button-container _ relative width-full  mk-button--anim-side block text-center  bottomborder">
                <a href="http://codeandtesting.com/services/" target="_blank" class="mk-button js-smooth-scroll mk-button--dimension-three mk-button--size-medium mk-button--corner-pointed text-color-dark _ relative text-center font-weight-700 no-backface  letter-spacing-1 block">
                  <span class="mk-button--text">Register</span>
                </a>
              </div>
            </div>
          </div>
  
        </div>
      
  

    </div>



  </div>


<div class="wrapper"> 

  <div class="wpb_row vc_row  mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
    <div class="mk-grid">
        <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
            <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Get Involved</span></h3>
            <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                <div class="wpb_column vc_column_container vc_col-sm-4">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="mk-image   align-center rounded-frame inside-image " style="margin-bottom:10px">
                                <div class="mk-image-holder" style="max-width:127px;">
                                    <div class="mk-image-inner ">
                                      <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/service-1.png" />
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                            </div>
                            <div id="text-block-3" class="mk-text-block   ">
                                <p style="text-align:center;" align="justify" class="bold-text">
                                  WE DO MEETINGS
                                </p>
                                <p style="text-align:center;" align="justify">
                                  We organise our meetings through the OpenCharity MeetUp group.
                                </p>
                                <div class="clearboth"></div>
                            </div>
                            <div class="service-button wpb_column vc_column_container vc_col-sm-12">
                              <a href="http://codeandtesting.com/services/" target="_blank" class="mk-button js-smooth-scroll mk-button--dimension-three mk-button--size-medium mk-button--corner-pointed text-color-dark _ relative text-center font-weight-700 no-backface  letter-spacing-1 block">
                                <span class="mk-button--text">Meetup Group</span>
                              </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="mk-image   align-center rounded-frame inside-image " style="margin-bottom:10px">
                                <div class="mk-image-holder" style="max-width:127px;">
                                    <div class="mk-image-inner ">
                                      <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/service-2.png" />
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                            </div>
                            <div id="text-block-3" class="mk-text-block">
                                <p style="text-align:center;" align="justify" class="bold-text">
                                  WE COLLABORATE
                                </p>
                                <p style="text-align:center;" align="justify">
                                  OpenCharity have a slack group for daily collaboration  
                                </p>
                                <div class="clearboth"></div>
                            </div>
                            <div class="service-button wpb_column vc_column_container vc_col-sm-12">
                              <a href="http://codeandtesting.com/services/" target="_blank" class="mk-button js-smooth-scroll mk-button--dimension-three mk-button--size-medium mk-button--corner-pointed text-color-dark _ relative text-center font-weight-700 no-backface  letter-spacing-1 block">
                                <span class="mk-button--text">Slack Group</span>
                              </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-4">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="mk-image   align-center rounded-frame inside-image " style="margin-bottom:10px">
                                <div class="mk-image-holder" style="max-width:127px;">
                                    <div class="mk-image-inner ">
                                      <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/service-3.png" />
                                    </div>
                                </div>
                                <div class="clearboth"></div>
                            </div>
                            <div id="text-block-3" class="mk-text-block   ">
                                <p style="text-align:center;" align="justify" class="bold-text">
                                   We Share
                                </p>
                                <p style="text-align:center;" align="justify">
                                 
                                  We have a Google Group set up to share tools and documents
                                </p>
                                <div class="clearboth"></div>
                            </div>
                            <div class="service-button wpb_column vc_column_container vc_col-sm-12">
                              <a href="http://codeandtesting.com/services/" target="_blank" class="mk-button js-smooth-scroll mk-button--dimension-three mk-button--size-medium mk-button--corner-pointed text-color-dark _ relative text-center font-weight-700 no-backface  letter-spacing-1 block">
                                <span class="mk-button--text">Google Group</span>
                              </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>

<div class="red-background">
  <div class="wrapper">
    <div class="wpb_row vc_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
      <div class="mk-grid">
          <div style="" class="about-section vc_col-sm-12 wpb_column column_container  _ height-full">
              <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>OUR MISSION</span></h3>
              <p style="text-align:center;" align="justify">
                                  Charities and Partners collaborating and sharing open solutions and ideas to create value in the digital space.
              </p>
              <p style="text-align:center;" align="justify" class="bold-text">
                  If you are a charity or a supplier, we are ready to welcome you.
              </p>
              <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                  <div class="wpb_column vc_column_container vc_col-sm-4">
                      <div class="vc_column-inner ">
                          <div class="wpb_wrapper">
                              <div class="mk-image   align-center rounded-frame inside-image white-section-top">
                                  <div class="mk-image-holder" style="max-width:127px;margin: 0 auto;">
                                      <div class="mk-image-inner ">
                                        <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/help.png" />
                                      </div>
                                  </div>
                                  <div class="clearboth"></div>
                              </div>
                              <div id="text-block-3" class="mk-text-block white-back-block">
                                  <p style="text-align:center;" align="justify" class="bold-text theme-color">
                                     We help charities
                                  </p>
                                  <p style="text-align:center;" align="justify">
                                    share knowledge and working practice to make the best technology choices.
                                  </p>
                                  <div class="clearboth"></div>
                              </div>
                           
                          </div>
                      </div>
                  </div>
                  <div class="wpb_column vc_column_container vc_col-sm-4">
                      <div class="vc_column-inner ">
                          <div class="wpb_wrapper">
                              <div class="mk-image   align-center rounded-frame inside-image white-section-top">
                                  <div class="mk-image-holder" style="max-width:127px;margin: 0 auto;">
                                      <div class="mk-image-inner ">
                                        <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/group.png" />
                                      </div>
                                  </div>
                                  <div class="clearboth"></div>
                              </div>
                              <div id="text-block-3" class="mk-text-block white-back-block">
                                  <p style="text-align:center;" align="justify" class="bold-text theme-color">
                                    We bring together
                                  </p>
                                  <p style="text-align:center;" align="justify">
                                    charities and suppliers to the charity sector to share best practices.
                                  </p>
                                  <div class="clearboth"></div>
                              </div>
                              
                          </div>
                      </div>
                  </div>
                  <div class="wpb_column vc_column_container vc_col-sm-4">
                      <div class="vc_column-inner ">
                          <div class="wpb_wrapper">
                              <div class="mk-image   align-center rounded-frame inside-image white-section-top">
                                  <div class="mk-image-holder" style="max-width:127px;margin: 0 auto;">
                                      <div class="mk-image-inner ">
                                        <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/like.png" />
                                      </div>
                                  </div>
                                  <div class="clearboth"></div>
                              </div>
                              <div id="text-block-3" class="mk-text-block white-back-block">
                                  <p style="text-align:center;" align="justify" class="bold-text theme-color">
                                    We encourage
                                  </p>
                                  <p style="text-align:center;" align="justify">
                                    collaboration and innovation for the good of the charity sector.
                                  </p>
                                  <div class="clearboth"></div>
                              </div>
                              
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div style="" class="member-section vc_col-sm-12 wpb_column column_container  _ height-full">
              <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>OUR MEMBERS</span></h3>
              <div class="row">
                  <div class="large-12 columns">
                    <div class="owl-carousel owl-theme">
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-7.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-6.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-5.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-4.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-3.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-2.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-1.png" />
                        </div>
                      </div>
                      <div class="item">
                        <div class="mk-image-inner ">
                          <img title="service1" src="<?php print $base_url; ?>/<?php print $directory;?>/images/partner-5.png" />
                        </div>
                      </div>
                      
                      <!-- <div class="item">
                        <h4>2</h4>
                      </div>
                      <div class="item">
                        <h4>3</h4>
                      </div>
                      <div class="item">
                        <h4>4</h4>
                      </div>
                      <div class="item">
                        <h4>5</h4>
                      </div>
                      <div class="item">
                        <h4>6</h4>
                      </div>
                      <div class="item">
                        <h4>7</h4>
                      </div>
                      <div class="item">
                        <h4>8</h4>
                      </div>
                      <div class="item">
                        <h4>9</h4>
                      </div>
                      <div class="item">
                        <h4>10</h4>
                      </div>
                      <div class="item">
                        <h4>11</h4>
                      </div>
                      <div class="item">
                        <h4>12</h4>
                      </div> -->
                    </div>
                  </div>
              </div>
              
          </div>
      </div>
    </div>
 
  </div>
</div>

<div class="wrapper"> 

  <div class="wpb_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
    <div class="mk-grid">
        <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
            <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Blog</span></h3>
            <div class="row">
                  <div class="large-12 columns">
                    <section class="slider">
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                      <div>
                      
                       
                          <p style="text-align:left;" align="justify" class="bold-text theme-color">
                                         We help charities
                                      </p>
                                      <p style="text-align:left; font-size:16px;" align="justify">
                                        share knowledge and working practice to make the best technology choices.
                                      </p>
                                      <div class="clearboth"></div>
                                 
                     
                      </div>
                    </section>




                  </div>
              </div>
        </div>
    </div>
  </div>
</div>


<!-- <div class="wrapper"> 
  <div id="content">
    <?php print render($title_prefix); ?>
      <?php if ($title): ?><h1><?php print $title; ?></h1><?php endif; ?>
    <?php print render($title_suffix); ?>

    <?php print render($messages); ?>
    <?php if ($tabs): ?><div class="tabs"><?php print render($tabs); ?></div><?php endif; ?>
    <?php if ($action_links): ?><ul class="action-links"><?php print render($action_links); ?></ul><?php endif; ?>

    <?php print render($page['content']); ?>
  </div>

  <?php if ($page['sidebar_first']): ?>    
    <div id="sidebar">
      <?php print render($page['sidebar_first']); ?>
    </div>
  <?php endif; ?>  

</div> -->


<div class="footer-wrapper">
  <div id="footer">

    <div class="wrapper"> 

      <div class="wpb_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
        <div class="mk-grid">
            <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
                <!-- <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Blog</span></h3>
                <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                 
                </div> -->
                <?php if ($page['footer']): ?>    
                  <?php print render($page['footer']); ?>
                <?php endif; ?> 
            </div>
        </div>
      </div>
    </div>
   
     

  </div>
  <div id="footer-copyright">

    <div class="wrapper"> 

      <div class="wpb_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
        <div class="mk-grid">
            <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
                <!-- <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Blog</span></h3>
                <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                 
                </div> -->
                <?php if ($page['copyright']): ?>    
                  <?php print render($page['copyright']); ?>
                <?php endif; ?> 
            </div>
        </div>
      </div>
    </div>
   
     

  </div>
</div>