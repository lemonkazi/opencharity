<?php
global $base_url;   // Will point to http://www.example.com
global $base_path;  // Will point to at least "/" or the subdirectory where the drupal in 
?>
<script type="text/javascript">

 jQuery(function($) {

  });
</script>


  <div id="header">

    <!-- <a href="<?php print $front_page;?>" title="<?php print $site_name;?>">
      <img class="mk-desktop-logo dark-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-desktop-logo light-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-resposnive-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
      <img class="mk-sticky-logo" title="Under Construction" alt="Under Construction" src="http://codeandtesting.com/wp-content/uploads/2016/08/code-and-testing-logo.png">
    </a> -->

    <a href="<?php print $front_page;?>" title="<?php print $site_name;?>">
      <img src="<?php print $base_url; ?>/<?php print $directory;?>/images/logo.png" alt="<?php print $site_name;?>" height="47" width="217" />
    </a>

    <?php if ($main_menu): ?>
        <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'main-menu'))); ?>
    <?php endif; ?>

  </div>

 


<div id="wrapper">  
  <div id="content">
    <?php print render($title_prefix); ?>
      <?php if ($title): ?><h1><?php print $title; ?></h1><?php endif; ?>
    <?php print render($title_suffix); ?>

    <?php print render($messages); ?>
    <?php if ($tabs): ?><div class="tabs"><?php print render($tabs); ?></div><?php endif; ?>
    <?php if ($action_links): ?><ul class="action-links"><?php print render($action_links); ?></ul><?php endif; ?>

    <?php print render($page['content']); ?>
  </div>

  <?php if ($page['sidebar_first']): ?>    
    <div id="sidebar">
      <?php print render($page['sidebar_first']); ?>
    </div>
  <?php endif; ?>  

</div>

<div class="footer-wrapper">
  <div id="footer">

    <div class="wrapper"> 

      <div class="wpb_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
        <div class="mk-grid">
            <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
                <!-- <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Blog</span></h3>
                <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                 
                </div> -->
                <?php if ($page['footer']): ?>    
                  <?php print render($page['footer']); ?>
                <?php endif; ?> 
            </div>
        </div>
      </div>
    </div>
   
     

  </div>
  <div id="footer-copyright">

    <div class="wrapper"> 

      <div class="wpb_row mk-fullwidth-true  attched-false    vc_row-fluid  equal-columns js-master-row  mk-in-viewport">
        <div class="mk-grid">
            <div style="" class="vc_col-sm-12 wpb_column column_container  _ height-full">
                <!-- <h3 class="mk-title-box-2 mk-title-box clearfix  mk-animate-element left-to-right  mk-in-viewport"><span>Blog</span></h3>
                <div class="wpb_row vc_inner vc_row    attched-false   vc_custom_1481265740407 vc_row-fluid ">
                 
                </div> -->
                <?php if ($page['copyright']): ?>    
                  <?php print render($page['copyright']); ?>
                <?php endif; ?> 
            </div>
        </div>
      </div>
    </div>
   
     

  </div>
</div>